// 公司能力展示页 - 交互脚本

document.addEventListener('DOMContentLoaded', function() {
    // 平滑滚动
    initSmoothScroll();
    
    // 动画效果
    initAnimations();
    
    // 联系表单处理
    initContactForm();
    
    // 导航高亮
    initNavHighlight();
});

// 平滑滚动
function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// 动画效果
function initAnimations() {
    // 观察器配置
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    
    // 创建观察器
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // 观察需要动画的元素
    const animatedElements = document.querySelectorAll('.service-card, .case-card, .advantage-item, .process-step');
    animatedElements.forEach(el => {
        observer.observe(el);
    });
    
    // 添加CSS动画类
    const style = document.createElement('style');
    style.textContent = `
        .service-card, .case-card, .advantage-item, .process-step {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.6s ease, transform 0.6s ease;
        }
        
        .animate-in {
            opacity: 1;
            transform: translateY(0);
        }
        
        .service-card:nth-child(1) { transition-delay: 0.1s; }
        .service-card:nth-child(2) { transition-delay: 0.2s; }
        .service-card:nth-child(3) { transition-delay: 0.3s; }
        .service-card:nth-child(4) { transition-delay: 0.4s; }
        
        .case-card:nth-child(1) { transition-delay: 0.1s; }
        .case-card:nth-child(2) { transition-delay: 0.2s; }
        .case-card:nth-child(3) { transition-delay: 0.3s; }
        
        .advantage-item:nth-child(1) { transition-delay: 0.1s; }
        .advantage-item:nth-child(2) { transition-delay: 0.2s; }
        .advantage-item:nth-child(3) { transition-delay: 0.3s; }
        .advantage-item:nth-child(4) { transition-delay: 0.4s; }
        
        .process-step:nth-child(1) { transition-delay: 0.1s; }
        .process-step:nth-child(2) { transition-delay: 0.2s; }
        .process-step:nth-child(3) { transition-delay: 0.3s; }
        .process-step:nth-child(4) { transition-delay: 0.4s; }
        .process-step:nth-child(5) { transition-delay: 0.5s; }
        .process-step:nth-child(6) { transition-delay: 0.6s; }
    `;
    document.head.appendChild(style);
}

// 联系表单处理
function initContactForm() {
    // 这里可以添加联系表单的处理逻辑
    // 目前页面使用mailto链接，后续可以替换为实际表单
    
    const contactButtons = document.querySelectorAll('.cta-button[href^="mailto"]');
    contactButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // 可以在这里添加点击统计等逻辑
            console.log('联系按钮被点击');
        });
    });
}

// 导航高亮
function initNavHighlight() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= (sectionTop - 100)) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// 复制联系信息
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('已复制到剪贴板: ' + text);
    }).catch(err => {
        console.error('复制失败:', err);
    });
}

// 添加复制功能到联系信息
document.addEventListener('DOMContentLoaded', function() {
    const contactItems = document.querySelectorAll('.contact-item');
    
    contactItems.forEach(item => {
        item.style.cursor = 'pointer';
        item.title = '点击复制';
        
        item.addEventListener('click', function() {
            const text = this.textContent.replace(/^[^:]+:\s*/, '');
            copyToClipboard(text);
        });
    });
});

// 页面加载进度
window.addEventListener('load', function() {
    const loader = document.createElement('div');
    loader.id = 'page-loader';
    loader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 3px;
        background: linear-gradient(90deg, #00bcd4, #1a237e);
        z-index: 9999;
        transform: translateX(-100%);
        transition: transform 0.3s ease-out;
    `;
    document.body.appendChild(loader);
    
    setTimeout(() => {
        loader.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        loader.style.transform = 'translateX(100%)';
        setTimeout(() => loader.remove(), 300);
    }, 500);
});